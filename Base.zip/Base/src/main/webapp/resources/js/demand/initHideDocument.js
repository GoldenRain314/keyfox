function hideDocument(){
	//数据库设计说明
	$("#shujukushejishuoming").hide();
	$("#shujukushejishuoming_name").hide();
	$("#shujukushejishuoming_version").hide();
	$("#shujukushejishuoming_xia").hide();
	
	//软件产品规格说明
	$("#ruanjianchanpinguigeshuoming").hide();
	$("#ruanjianchanpinguigeshuoming_name").hide();
	$("#ruanjianchanpinguigeshuoming_version").hide();
	$("#ruanjianchanpinguigeshuoming_xia").hide();
	
	//软件研制任务书
	$("#ruanjianyanzhirenwushu").hide();
	$("#ruanjianyanzhirenwushu_name").hide();
	$("#ruanjianyanzhirenwushu_version").hide();
	
	//软件需求规格说明
	$("#ruanjianxuqiuguogeshuoming").hide();
	$("#ruanjianxuqiuguogeshuoming_name").hide();
	$("#ruanjianxuqiuguogeshuoming_version").hide();
	$("#ruanjianxuqiuguogeshuoming_zuo").hide();
	
	//软件设计说明
	$("#ruanjianshejishuoming").hide();
	$("#ruanjianshejishuoming_name").hide();
	$("#ruanjianshejishuoming_version").hide();
	$("#ruanjianshejishuoming_zuo").hide();
	
	//软件单元测试说明
	$("#ruanjiandanyuanceshishuoming").hide();
	$("#ruanjiandanyuanceshishuoming_name").hide();
	$("#ruanjiandanyuanceshishuoming_version").hide();
	$("#ruanjiandanyuanceshishuoming_zuo").hide();
	
	//软件单元测试计划
	$("#ruanjiandanyuanceshijihua").hide();
	$("#ruanjiandanyuanceshijihua_name").hide();
	$("#ruanjiandanyuanceshijihua_version").hide();
	$("#ruanjiandanyuanceshijihua_zuo").hide();
	
	//软件系统测试计划
	$("#ruanjianxitongceshijihua").hide();
	$("#ruanjianxitongceshijihua_name").hide();
	$("#ruanjianxitongceshijihua_version").hide();
	$("#ruanjianxitongceshijihua_shang").hide();
	
	//软件配置项测试计划
	$("#ruanjianpeizhixiangceshijihua").hide();
	$("#ruanjianpeizhixiangceshijihua_name").hide();
	$("#ruanjianpeizhixiangceshijihua_version").hide();
	$("#ruanjianpeizhixiangceshijihua_shang").hide();
	
	//软件部件测试计划
	$("#ruanjianbujianceshijihua").hide();
	$("#ruanjianbujianceshijihua_name").hide();
	$("#ruanjianbujianceshijihua_version").hide();
	$("#ruanjianbujianceshijihua_shang").hide();
	
	
	//软件部件测试说明
	$("#ruanjianbujianceshishuoming").hide();
	$("#ruanjianbujianceshishuoming_name").hide();
	$("#ruanjianbujianceshishuoming_version").hide();
	$("#ruanjianbujianceshishuoming_zuo").hide();
	
	//软件系统测试说明
	$("#ruanjianxitongceshishuoming").hide();
	$("#ruanjianxitongceshishuoming_name").hide();
	$("#ruanjianxitongceshishuoming_version").hide();
	$("#ruanjianxitongceshishuoming_shang").hide();
	
	//软件配置项测试说明
	$("#ruanjianpeizhixiangceshishuoming").hide();
	$("#ruanjianpeizhixiangceshishuoming_name").hide();
	$("#ruanjianpeizhixiangceshishuoming_version").hide();
	$("#ruanjianpeizhixiangceshishuoming_shang").hide();
	
	//接口需求规格说明
	$("#jiekouxuqiuguigeshuoming").hide();
	$("#jiekouxuqiuguigeshuoming_name").hide();
	$("#jiekouxuqiuguigeshuoming_version").hide();
	
	//接口设计说明
	$("#jiekoushejishuoming").hide();
	$("#jiekoushejishuoming_name").hide();
	$("#jiekoushejishuoming_version").hide();
	$("#jiekoushejishuoming_zuo").hide();
	
	//系统（子系统）规格说明
	$("#xitongzixitongxuqiuguigeshuoming").hide();
	$("#xitongzixitongxuqiuguigeshuoming_name").hide();
	$("#xitongzixitongxuqiuguigeshuoming_version").hide();
	
	//系统（子系统）设计说明
	$("#xitongzixitongshejishuoming").hide();
	$("#xitongzixitongshejishuoming_name").hide();
	$("#xitongzixitongshejishuoming_version").hide();
	$("#xitongzixitongshejishuoming_zuo").hide();
	
	//软件测试计划
	$("#ruanjianceshijihua").hide();
	$("#ruanjianceshijihua_name").hide();
	$("#ruanjianceshijihua_version").hide();
	
	//软件测试说明
	$("#ruanjianceshishuoming").hide();
	$("#ruanjianceshishuoming_name").hide();
	$("#ruanjianceshishuoming_version").hide();
	$("#ruanjianceshishuoming_zuo").hide();
}