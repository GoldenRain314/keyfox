// JavaScript Document
$(function($){
	//页面动画
	(function(){
		$('.wp1').waypoint(function() {
			$('.wp1').addClass('animated fadeInDown');
			},{
				offset: '75%'
		});
		$('.wp1_text1').waypoint(function() {
			$('.wp1_text1').addClass('animated fadeInLeft');
			},{
				offset: '75%'
		});
		$('.wp1_text2').waypoint(function() {
			$('.wp1_text2').addClass('animated fadeInRight');
			},{
				offset: '75%'
		});
		$('.wp2').waypoint(function() {
			$('.wp2').addClass('animated fadeInDown');
		}, {
			offset: '75%'
		});
		$('.wp2_text1').waypoint(function() {
			$('.wp2_text1').addClass('animated fadeInLeft');
			},{
				offset: '75%'
		});
		$('.wp2_text2').waypoint(function() {
			$('.wp2_text2').addClass('animated fadeInRight');
			},{
				offset: '75%'
		});
		$('.wp3').waypoint(function() {
			$('.wp3').addClass('animated fadeInDown');
			},{
				offset: '75%'
		});
		$('.wp3_text1').waypoint(function() {
			$('.wp3_text1').addClass('animated fadeInUp');
			},{
				offset: '75%'
		});
		$('.wp4').waypoint(function() {
			$('.wp4').addClass('animated fadeInDown');
		}, {
			offset: '75%'
		});
		$('.wp4_text1').waypoint(function() {
			$('.wp4_text1').addClass('animated fadeInUp');
			},{
				offset: '75%'
		});
		$('.wp5').waypoint(function() {
			$('.wp5').addClass('animated fadeInDown');
		}, {
			offset: '75%'
		});
		$('.wp5_text1').waypoint(function() {
			$('.wp5_text1').addClass('animated fadeInUp');
			},{
				offset: '75%'
		});
		$('.wp6').waypoint(function() {
			$('.wp6').addClass('animated fadeInDown');
			},{
				offset: '75%'
		});
		$('.wp6_text1').waypoint(function() {
			$('.wp6_text1').addClass('animated fadeInUp');
			},{
				offset: '75%'
		});
		$('.wp7').waypoint(function() {
			$('.wp7').addClass('animated fadeInDown');
		}, {
			offset: '75%'
		});
		$('.wp8').waypoint(function() {
			$('.wp8').addClass('animated fadeInDown');
		}, {
			offset: '75%'
		});
		$('.wp8_text1').waypoint(function() {
			$('.wp8_text1').addClass('animated fadeInUp');
			},{
				offset: '75%'
		});
		$('.wp8_text2').waypoint(function() {
			$('.wp8_text2').addClass('animated fadeInUp');
			},{
				offset: '75%'
		});
		
	})();
	
	
	
});

